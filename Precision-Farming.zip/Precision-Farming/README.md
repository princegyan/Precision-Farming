# PrecisionFarming
This is a final year project work by Prince Alfred Gyan and Dennis Effa Amponsah. It  employs the use of IOT to monitor, store and analyse soil conditions in a green house to enhance crop production. The microcontroller used is the raspberry pi.

# Contributing
This project is not open for contributions yet.